import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { getYearsOfExperienceLabel } from '../utils/experience';
import SectionBadge from './SectionBadge';

export default function About() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const years = getYearsOfExperienceLabel();

  return (
    <section id="about" className="section-container" aria-label="About me">
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 40 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <SectionBadge>Background</SectionBadge>
        <h2 className="section-title text-gradient text-center">About Me</h2>
        <p className="section-subtitle text-center">My journey in tech</p>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div className="space-y-5 text-gray-600 dark:text-glow-100/55 leading-relaxed">
            <p>
              I'm an engineer transitioning into{' '}
              <strong className="text-gray-900 dark:text-glow-100">AI Engineering</strong>,
              building production-grade systems with{' '}
              <strong className="text-gray-900 dark:text-glow-100">LLMs</strong>,{' '}
              <strong className="text-gray-900 dark:text-glow-100">RAG pipelines</strong>,
              and{' '}
              <strong className="text-gray-900 dark:text-glow-100">multi-agent
              workflows</strong>{' '}
              via Python, LangChain, LangGraph, and vector databases like ChromaDB.
            </p>
            <p>
              Behind that is{' '}
              <strong className="text-gray-900 dark:text-glow-100">{years} years</strong>{' '}
              shipping enterprise software at scale —{' '}
              <strong className="text-gray-900 dark:text-glow-100">Java 8–17</strong>,{' '}
              <strong className="text-gray-900 dark:text-glow-100">Spring Boot</strong>,
              and{' '}
              <strong className="text-gray-900 dark:text-glow-100">microservices</strong>{' '}
              across Telecom, Supply Chain, Railroads, and Finance. I bring the
              production rigor (observability, CI/CD, Kubernetes, async messaging)
              that LLM applications need to actually work in the wild.
            </p>
            <p>
              Currently a Cloud Consultant at Concentrix, delivering the SCM
              platform for{' '}
              <strong className="text-gray-900 dark:text-glow-100">T-Mobile</strong>{' '}
              while building personal AI projects on the side — RAG document
              assistants, multi-agent systems, and self-hosted LLM tooling. My
              goal: ship AI features end-to-end, not just call APIs.
            </p>
          </div>

          <div className="space-y-4">
            {[
              { label: 'Experience', value: `${years} Years` },
              { label: 'Current Role', value: 'Cloud Consultant, Concentrix' },
              { label: 'Current Client', value: 'T-Mobile (Supply Chain Mgmt)' },
              { label: 'Domains', value: 'Telecom · Supply Chain · Railroads · Finance' },
              { label: 'Location', value: 'Hyderabad, India' },
              { label: 'Education', value: 'B.Tech, Electronics & Communication' },
              { label: 'Interests', value: 'AI, Cricket, Cryptocurrency' },
            ].map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, x: 20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.1 * index, ease: 'easeOut' }}
                className="flex items-center gap-4 p-4 rounded-lg bg-gray-50 dark:bg-ink-900
                           border border-gray-200 dark:border-glow-200/[0.08]"
              >
                <span className="text-sm font-medium text-gray-500 dark:text-glow-100/55 w-28 shrink-0">
                  {item.label}
                </span>
                <span className="text-sm font-semibold text-gray-900 dark:text-glow-100">
                  {item.value}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}
