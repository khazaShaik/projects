import { useState, useEffect } from 'react';
import { Link } from 'react-scroll';
import { motion, AnimatePresence } from 'framer-motion';
import { HiSun, HiMoon, HiBars3, HiXMark } from 'react-icons/hi2';

const navLinks = [
  { to: 'about', label: 'About' },
  { to: 'skills', label: 'Skills' },
  { to: 'projects', label: 'Projects' },
  { to: 'certifications', label: 'Certifications' },
  { to: 'experience', label: 'Experience' },
  { to: 'contact', label: 'Contact' },
];

export default function Navbar({ isDark, toggleTheme }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  return (
    <nav
      role="navigation"
      aria-label="Main navigation"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/80 dark:bg-ink-950/80 backdrop-blur-lg border-b border-gray-200/50 dark:border-glow-200/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link
            to="hero"
            smooth
            duration={500}
            className="text-xl font-bold cursor-pointer tracking-tight"
            aria-label="Go to top"
          >
            <span className="text-primary-600">K</span>S
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                smooth
                offset={-64}
                duration={500}
                spy
                activeClass="text-primary-600 dark:text-glow-100"
                className="px-3 py-2 text-sm font-medium text-gray-600 dark:text-glow-100/55
                           hover:text-gray-900 dark:hover:text-glow-100 cursor-pointer
                           transition-colors duration-200 rounded-lg"
              >
                {link.label}
              </Link>
            ))}

            <button
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="ml-2 p-2 rounded-lg text-gray-600 dark:text-glow-100/70
                         hover:bg-gray-100 dark:hover:bg-ink-800 transition-colors"
            >
              {isDark ? <HiSun className="w-5 h-5" /> : <HiMoon className="w-5 h-5" />}
            </button>
          </div>

          {/* Mobile controls */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 rounded-lg text-gray-600 dark:text-glow-100/70
                         hover:bg-gray-100 dark:hover:bg-ink-800 transition-colors"
            >
              {isDark ? <HiSun className="w-5 h-5" /> : <HiMoon className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileOpen}
              className="p-2 rounded-lg text-gray-600 dark:text-glow-100/70
                         hover:bg-gray-100 dark:hover:bg-ink-800 transition-colors"
            >
              {mobileOpen ? <HiXMark className="w-5 h-5" /> : <HiBars3 className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-white dark:bg-ink-950 border-b border-gray-200 dark:border-glow-200/10"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  smooth
                  offset={-64}
                  duration={500}
                  onClick={() => setMobileOpen(false)}
                  className="block px-3 py-2 text-base font-medium text-gray-600 dark:text-glow-100/60
                             hover:text-gray-900 dark:hover:text-glow-100 cursor-pointer
                             rounded-lg hover:bg-gray-50 dark:hover:bg-ink-900 transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
