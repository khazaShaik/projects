import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { HiAcademicCap, HiArrowTopRightOnSquare } from 'react-icons/hi2';
import certifications from '../data/certifications';
import SectionBadge from './SectionBadge';

export default function Certifications() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const isEmpty = !certifications || certifications.length === 0;

  return (
    <section id="certifications" className="section-container" aria-label="Certifications">
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 40 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <SectionBadge>Credentials</SectionBadge>
        <h2 className="section-title text-gradient text-center">Certifications</h2>
        <p className="section-subtitle text-center">Professional credentials</p>

        {isEmpty && (
          <div className="card text-center py-12">
            <HiAcademicCap className="w-10 h-10 text-gray-300 dark:text-gray-700 mx-auto mb-3" />
            <p className="text-sm text-gray-500 dark:text-glow-100/55">
              Certifications in progress — currently upskilling in AI Engineering
              (LangChain, RAG, and LLM specializations).
            </p>
          </div>
        )}

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.08 * index, ease: 'easeOut' }}
              style={{ '--glow-duration': `${9 + (index % 4) * 3}s` }}
              className="card card-glow group"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary-50 dark:bg-primary-900/20 shrink-0">
                  <HiAcademicCap className="w-5 h-5 text-primary-600 dark:text-primary-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-semibold leading-snug mb-1">{cert.title}</h3>
                  <p className="text-xs text-gray-500 dark:text-glow-100/55">{cert.issuer}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-gray-400 dark:text-glow-100/40 font-mono">
                      {cert.date}
                    </span>
                    <a
                      href={cert.credentialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`View credential for ${cert.title}`}
                      className="text-gray-400 hover:text-primary-500 transition-colors"
                    >
                      <HiArrowTopRightOnSquare className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
