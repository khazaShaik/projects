import { FaGithub, FaLinkedin } from 'react-icons/fa';
import { HiHeart, HiEnvelope } from 'react-icons/hi2';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer
      role="contentinfo"
      className="border-t border-gray-200 dark:border-glow-200/[0.08]"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500 dark:text-glow-100/55 flex items-center gap-1">
            &copy; {year} Khaza Shaik. Built with
            <HiHeart className="w-4 h-4 text-red-500 inline" aria-hidden="true" />
            and React.
          </p>

          <div className="flex items-center gap-4">
            <a
              href="https://github.com/khazaShaik"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="text-gray-400 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
            >
              <FaGithub className="w-5 h-5" />
            </a>
            <a
              href="https://linkedin.com/in/khaza-shaik-3344b5157"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="text-gray-400 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
            >
              <FaLinkedin className="w-5 h-5" />
            </a>
            <a
              href="mailto:shaikkhaza4@gmail.com"
              aria-label="Email"
              className="text-gray-400 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
            >
              <HiEnvelope className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
