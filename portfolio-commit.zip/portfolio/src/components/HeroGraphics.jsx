/**
 * Decorative graphics layer for the Hero section, inspired by AuthKit.
 * Renders three layers:
 *   1. A faint horizontal + vertical hairline grid
 *   2. Plus/cross markers at the grid intersections
 *   3. Three soft drifting spotlights (dark mode only)
 *
 * All decorative — pointer-events disabled, aria-hidden.
 */
export default function HeroGraphics() {
  // Percentages for grid lines — chosen so crosses land on intersections
  const hLines = ['18%', '50%', '82%'];
  const vLines = ['18%', '50%', '82%'];

  // Cross/plus markers placed at intersection corners
  const crosses = [
    { top: '18%', left: '18%' },
    { top: '18%', left: '82%' },
    { top: '82%', left: '18%' },
    { top: '82%', left: '82%' },
  ];

  return (
    <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none" aria-hidden="true">
      {/* === Soft drifting spotlights (dark mode only) === */}
      <div className="hidden dark:block absolute inset-0">
        <div className="hero-spotlight hero-spotlight-1" />
        <div className="hero-spotlight hero-spotlight-2" />
        <div className="hero-spotlight hero-spotlight-3" />
      </div>

      {/* === Grid hairlines === */}
      <div className="absolute inset-0">
        {hLines.map((top) => (
          <div key={`h-${top}`} className="hero-hline" style={{ top }} />
        ))}
        {vLines.map((left) => (
          <div key={`v-${left}`} className="hero-vline" style={{ left }} />
        ))}
      </div>

      {/* === Plus/cross intersection markers === */}
      {crosses.map(({ top, left }, i) => (
        <span
          key={`x-${i}`}
          className="hero-cross"
          style={{ top, left }}
        />
      ))}
    </div>
  );
}
