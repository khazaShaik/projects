/**
 * Small pill badge flanked by horizontal hairlines.
 * Inspired by AuthKit's "Introducing" / "Shine bright" / "Framework freedom" markers.
 */
export default function SectionBadge({ children, className = '' }) {
  return (
    <div className={`between-lines mb-4 ${className}`}>
      <div className="pill-badge">
        <span className="pill-badge-text">{children}</span>
      </div>
    </div>
  );
}
