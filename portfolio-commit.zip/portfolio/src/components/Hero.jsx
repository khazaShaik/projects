import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-scroll';
import { HiArrowDown, HiEnvelope, HiSun, HiMoon } from 'react-icons/hi2';
import { FaGithub, FaLinkedin } from 'react-icons/fa';
import { getYearsOfExperienceLabel } from '../utils/experience';
import useReducedMotion from '../hooks/useReducedMotion';
import SectionBadge from './SectionBadge';
import HeroGraphics from './HeroGraphics';
import HeroCards from './HeroCards';
import TechMarquee from './TechMarquee';

const ROLES = [
  'Senior Software Engineer',
  'Java Full-stack Developer',
  'AI Engineer',
  'Cloud Consultant',
];

export default function Hero() {
  const years = getYearsOfExperienceLabel();
  const reducedMotion = useReducedMotion();
  const [roleIndex, setRoleIndex] = useState(0);

  useEffect(() => {
    if (reducedMotion) return;
    const id = setInterval(() => {
      setRoleIndex((prev) => (prev + 1) % ROLES.length);
    }, 2800);
    return () => clearInterval(id);
  }, [reducedMotion]);

  return (
    <section
      id="hero"
      className="min-h-screen flex items-center justify-center relative overflow-hidden pt-24 pb-12"
      aria-label="Introduction"
    >
      {/* Backdrop layers (dot grid + grid lines + crosses + spotlights) */}
      <div className="absolute inset-0 -z-20 dot-grid-light dark:dot-grid" aria-hidden="true" />
      <HeroGraphics />

      <div className="section-container text-center !py-0">
        {/* === Top half: badge + name + tagline === */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          <SectionBadge>Portfolio</SectionBadge>

          {/* Availability signal — first thing a recruiter wants to see */}
          <div className="flex justify-center mb-4">
            <span className="availability-pill" aria-label="Currently open to AI Engineering roles">
              <span className="availability-pill-dot" aria-hidden="true" />
              Open to AI Engineering roles
            </span>
          </div>

          <div className="outline-box inline-block px-8 py-4 mb-4 mx-auto">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-gradient">
              Khaza Shaik
            </h1>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2, ease: 'easeOut' }}
            className="text-lg sm:text-xl md:text-2xl text-gray-500 dark:text-glow-100/60 font-light mb-3 h-7 sm:h-8 md:h-10"
            aria-live="polite"
          >
            <span className="inline-block">I'm a&nbsp;</span>
            <span className="relative inline-block text-primary-600 dark:text-glow-100 font-normal align-bottom">
              <AnimatePresence mode="wait">
                <motion.span
                  key={ROLES[roleIndex]}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="inline-block"
                >
                  {ROLES[roleIndex]}
                </motion.span>
              </AnimatePresence>
            </span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35, ease: 'easeOut' }}
            className="max-w-2xl mx-auto text-gray-500 dark:text-glow-100/55 text-sm md:text-base leading-relaxed"
          >
            {years} years building enterprise-scale applications. Now pioneering
            the intersection of traditional software engineering and AI —
            crafting intelligent systems with LLMs, RAG, and AI Agents.
          </motion.p>
        </motion.div>

        {/* === Centerpiece: 3 fanned perspective cards === */}
        <HeroCards />

        {/* === "Light and dark modes supported" hint (AuthKit echo) === */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="flex items-center justify-center gap-2 text-xs text-gray-400 dark:text-glow-100/40 mb-6"
        >
          <HiSun className="w-3.5 h-3.5" aria-hidden="true" />
          <span>/</span>
          <HiMoon className="w-3.5 h-3.5" aria-hidden="true" />
          <span className="ml-1">Light and dark modes supported.</span>
        </motion.div>

        {/* Social links — primary CTAs (Contact / Resume) live in the centerpiece card above */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.65 }}
          className="flex items-center justify-center gap-4 mb-12"
        >
          <a
            href="https://github.com/khazaShaik"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub profile"
            className="p-2 text-gray-400 dark:text-glow-100/40 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
          >
            <FaGithub className="w-6 h-6" />
          </a>
          <a
            href="https://linkedin.com/in/khaza-shaik-3344b5157"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn profile"
            className="p-2 text-gray-400 dark:text-glow-100/40 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
          >
            <FaLinkedin className="w-6 h-6" />
          </a>
          <a
            href="mailto:shaikkhaza4@gmail.com"
            aria-label="Send email"
            className="p-2 text-gray-400 dark:text-glow-100/40 hover:text-gray-900 dark:hover:text-glow-100 transition-colors"
          >
            <HiEnvelope className="w-6 h-6" />
          </a>
        </motion.div>

        {/* === Tech marquee — AuthKit-style feature strip === */}
        <TechMarquee />
      </div>

      {/* Scroll-down indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.6 }}
        className="absolute bottom-4 left-1/2 -translate-x-1/2"
      >
        <Link to="about" smooth offset={-64} duration={500} className="cursor-pointer">
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className="text-gray-400 dark:text-glow-100/40"
          >
            <HiArrowDown className="w-5 h-5" />
          </motion.div>
        </Link>
      </motion.div>
    </section>
  );
}
