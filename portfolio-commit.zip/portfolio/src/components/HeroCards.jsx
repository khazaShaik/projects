import { motion } from 'framer-motion';
import { scroller } from 'react-scroll';
import {
  HiBriefcase,
  HiCpuChip,
  HiArrowRight,
  HiSparkles,
} from 'react-icons/hi2';
import { SiLangchain, SiPython, SiOpenai } from 'react-icons/si';

/**
 * AuthKit-style trio of fanned demo cards.
 *
 * Side cards are real <button>s wired to react-scroll's `scroller` API —
 * bulletproof click handling regardless of perspective transforms.
 *
 *   Left   → "Currently Shipping" → scrolls to Experience
 *   Center → Profile / Get-in-touch (the showpiece)
 *   Right  → "Building with AI"   → scrolls to Projects
 */

const scrollTo = (target) =>
  scroller.scrollTo(target, { smooth: true, offset: -64, duration: 500 });

export default function HeroCards() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.6, ease: 'easeOut' }}
      className="hero-cards-stage"
      aria-label="Profile highlights"
    >
      {/* === LEFT card → Experience === */}
      <button
        type="button"
        onClick={() => scrollTo('experience')}
        aria-label="Jump to Experience section"
        className="hero-card hero-card-left card card-glow"
        style={{ '--glow-duration': '14s' }}
      >
        <div className="hero-card-header">
          <div className="hero-card-logo bg-orange-500/15 text-orange-400">
            <HiBriefcase className="w-5 h-5" />
          </div>
          <h3 className="hero-card-title">Currently Shipping</h3>
          <p className="hero-card-subtitle">Cloud Consultant @ Concentrix</p>
        </div>

        <div className="hero-card-field">
          <span className="hero-card-field-label">Client</span>
          <span className="hero-card-field-value">T-Mobile · SCM Platform</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {['Java 17', 'Spring Boot', 'Angular 16'].map((t) => (
            <span key={t} className="hero-card-chip">{t}</span>
          ))}
        </div>

        <span className="hero-card-btn">
          View role <HiArrowRight className="w-3.5 h-3.5" />
        </span>
      </button>

      {/* === CENTER card — profile (its own internal CTAs) === */}
      <article
        className="hero-card hero-card-center card card-glow"
        style={{ '--glow-duration': '11s' }}
      >
        <div className="hero-card-header">
          <div className="hero-card-avatar">KS</div>
          <h3 className="hero-card-title text-base">Khaza Shaik</h3>
          <p className="hero-card-subtitle">Senior Software Engineer</p>
        </div>

        <div className="hero-card-field">
          <span className="hero-card-field-label">Email</span>
          <span className="hero-card-field-value truncate">shaikkhaza4@gmail.com</span>
        </div>

        <button
          type="button"
          onClick={() => scrollTo('contact')}
          className="hero-card-btn-primary"
        >
          Get in Touch
        </button>

        <div className="hero-card-divider"><span>OR</span></div>

        <a
          href="/resume.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="hero-card-btn"
        >
          Download Resume
        </a>
      </article>

      {/* === RIGHT card → Projects === */}
      <button
        type="button"
        onClick={() => scrollTo('projects')}
        aria-label="Jump to Projects section"
        className="hero-card hero-card-right card card-glow"
        style={{ '--glow-duration': '17s' }}
      >
        <div className="hero-card-header">
          <div className="hero-card-logo bg-violet-500/15 text-violet-400">
            <HiSparkles className="w-5 h-5" />
          </div>
          <h3 className="hero-card-title">Building with AI</h3>
          <p className="hero-card-subtitle">RAG · Agents · Function Calling</p>
        </div>

        {/* Concrete stack — what an AI recruiter wants to see */}
        <div className="hero-card-field">
          <span className="hero-card-field-label">Stack</span>
          <span className="hero-card-field-value text-[11px]">
            LangChain · LangGraph · ChromaDB
          </span>
        </div>

        <div className="hero-card-icons">
          {[
            { Icon: SiPython, label: 'Python', color: '#3776AB' },
            { Icon: SiOpenai, label: 'GPT-4', color: '#10A37F' },
            { Icon: SiLangchain, label: 'LangChain', color: '#00BB7E' },
          ].map(({ Icon, label, color }) => (
            <div key={label} className="hero-card-icon-tile">
              <Icon className="w-5 h-5" style={{ color }} />
              <span className="text-[10px]">{label}</span>
            </div>
          ))}
        </div>

        <span className="hero-card-btn">
          View AI projects <HiArrowRight className="w-3.5 h-3.5" />
        </span>
      </button>
    </motion.div>
  );
}
