import useDarkMode from './hooks/useDarkMode';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Certifications from './components/Certifications';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ScrollProgress from './components/ScrollProgress';
import ScrollToTop from './components/ScrollToTop';

// Hairline divider used between sections (AuthKit-style)
const Separator = () => <hr className="section-separator" aria-hidden="true" />;

export default function App() {
  const { isDark, toggle } = useDarkMode();

  return (
    <div className="min-h-screen">
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>

      <ScrollProgress />
      <Navbar isDark={isDark} toggleTheme={toggle} />

      <main id="main-content">
        <Hero />
        <Separator />
        <About />
        <Separator />
        <Skills />
        <Separator />
        <Projects />
        <Separator />
        <Certifications />
        <Separator />
        <Experience />
        <Separator />
        <Contact />
      </main>

      <Footer />
      <ScrollToTop />
    </div>
  );
}
